const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Test endpoint to check the server
app.get('/', (req, res) => {
    res.send('Backend is running!');
});

// Route to execute code
app.post('/execute', async (req, res) => {
    const { language, code, input } = req.body;

    if (!language || !code) {
        return res.status(400).json({ error: 'Language and code are required!' });
    }

    try {
        const response = await axios.post('https://emkc.org/api/v2/piston/execute', {
            language,
            version: '*',
            files: [{ name: 'main', content: code }],
            stdin: input
        });

        const result = response.data;

        if (result.run) {
            res.json({
                stdout: result.run.stdout.trim(),
                stderr: result.run.stderr.trim(),
                code: result.run.code,
            });
        } else {
            res.status(500).json({ error: 'Failed to execute code!' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error connecting to the code execution engine.' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
