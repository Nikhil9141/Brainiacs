const questions = [
    "Write a program to print 'Hello, World!'",
    "Write a program to calculate the factorial of a number.",
    "Write a program to reverse a string.",
];

let currentQuestion = 0;

document.getElementById("submit-btn").addEventListener("click", async () => {
    const code = document.getElementById("code-input").value;
    const language = document.getElementById("language").value;

    if (!code) {
        alert("Please write some code!");
        return;
    }

    // Map language options to Judge0 IDs
    const languageMap = {
        c: 50,
        cpp: 54,
        java: 62,
        python: 71,
        javascript: 63,
    };

    const clientId = "ade6320456000026af98662799d78cd9"; // Replace with your JDoodle client ID
    const clientSecret = "4e43d40281b90d07595bcd30eb18451b864950ffbde75ec005773161095bb857"; // Replace with your JDoodle client secret

    // Sending code for execution
    const response = await fetch("https://api.jdoodle.com/v1/execute", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Client-ID": clientId,
            "Client-Secret": clientSecret
        },
        body: JSON.stringify({
            source_code: code,
            language_id: languageMap[language],
        }),
    });

    const result = await response.json();
    const token = result.token;

    // Polling for result
    let output = "Processing...";
    while (output === "Processing...") {
        const status = await fetch(
            `https://api.jdoodle.com/v1/submissions/${token}`,
            {
                method: "GET",
                headers: {
                    "Client-ID": clientId,
                    "Client-Secret": clientSecret
                },
            }
        );

        const statusResult = await status.json();
        if (statusResult.stdout) {
            output = statusResult.stdout;
        } else if (statusResult.stderr) {
            output = statusResult.stderr;
        } else {
            output = "Processing...";
        }
    }

    // Display Output
    document.getElementById("output-result").textContent = output;

    // Move to next question if correct
    if (output.trim() === "Hello, World!\n") {
        currentQuestion++;
        if (currentQuestion < questions.length) {
            document.getElementById("question-text").textContent =
                `Question ${currentQuestion + 1}: ${questions[currentQuestion]}`;
            document.getElementById("code-input").value = "";
        } else {
            alert("Congratulations! You have completed all questions.");
        }
    }
});
