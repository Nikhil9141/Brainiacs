class CodingChallengePlatform {
    constructor() {
        this.currentProblem = null;
        this.problems = [
            {
                title: "Sum of Two Numbers",
                description: "Write a function that takes two numbers and returns their sum.",
                testCases: [
                    { input: [5, 3], expectedOutput: 8 },
                    { input: [-1, 1], expectedOutput: 0 }
                ],
                startCode: {
                    python: "def solve(a, b):\n    # Your code here\n    pass\n",
                    javascript: "function solve(a, b) {\n    // Your code here\n}\n",
                    cpp: "int solve(int a, int b) {\n    // Your code here\n    return 0;\n}\n",
                    java: "public int solve(int a, int b) {\n    // Your code here\n    return 0;\n}\n"
                }
            },
            {
                title: "String Reversal",
                description: "Write a function that takes a string and returns its reverse.",
                testCases: [
                    { input: ["hello"], expectedOutput: "olleh" },
                    { input: ["python"], expectedOutput: "nohtyp" }
                ],
                startCode: {
                    python: "def solve(s):\n    # Your code here\n    pass\n",
                    javascript: "function solve(s) {\n    // Your code here\n}\n",
                    cpp: "string solve(string s) {\n    // Your code here\n    return s;\n}\n",
                    java: "public String solve(String s) {\n    // Your code here\n    return \"\";\n}\n"
                }
            }
        ];
    }

    initializeEventListeners() {
        document.getElementById('start-challenge').addEventListener('click', () => this.startChallenge());
        document.getElementById('run-code').addEventListener('click', () => this.runCode());
        document.getElementById('submit-solution').addEventListener('click', () => this.submitSolution());
        document.getElementById('next-problem').addEventListener('click', () => this.loadNextProblem());
    }

    startChallenge() {
        this.loadRandomProblem();
        document.getElementById('next-problem').style.display = 'none';
    }

    loadRandomProblem() {
        const randomIndex = Math.floor(Math.random() * this.problems.length);
        this.currentProblem = this.problems[randomIndex];
        
        const languageSelect = document.getElementById('language-select');
        const selectedLanguage = languageSelect.value;

        document.getElementById('problem-title').textContent = this.currentProblem.title;
        document.getElementById('problem-description').textContent = this.currentProblem.description;
        document.getElementById('code-editor').value = this.currentProblem.startCode[selectedLanguage];
    }

    async runCode() {
        const code = document.getElementById('code-editor').value;
        const language = document.getElementById('language-select').value;
        const errorDisplay = document.getElementById('error-display');

        try {
            const response = await this.compilePiston(code, language);
            
            if (response.run.stderr) {
                errorDisplay.textContent = response.run.stderr;
                errorDisplay.style.display = 'block';
            } else {
                errorDisplay.style.display = 'none';
                alert(`Output: ${response.run.stdout}`);
            }
        } catch (error) {
            errorDisplay.textContent = `Compilation Error: ${error.message}`;
            errorDisplay.style.display = 'block';
        }
    }

    async submitSolution() {
        const code = document.getElementById('code-editor').value;
        const language = document.getElementById('language-select').value;
        const errorDisplay = document.getElementById('error-display');

        try {
            // Simulate test case checking
            const testResults = await this.runTestCases(code, language);
            
            if (testResults.allPassed) {
                errorDisplay.style.display = 'none';
                alert('Congratulations! All test cases passed.');
                document.getElementById('next-problem').style.display = 'block';
            } else {
                errorDisplay.textContent = `Failed test cases: ${testResults.failedCases}`;
                errorDisplay.style.display = 'block';
            }
        } catch (error) {
            errorDisplay.textContent = `Submission Error: ${error.message}`;
            errorDisplay.style.display = 'block';
        }
    }

    async runTestCases(code, language) {
        const results = {
            allPassed: true,
            failedCases: []
        };

        for (const testCase of this.currentProblem.testCases) {
            const response = await this.compilePiston(code, language, testCase.input);
            
            if (response.run.stderr) {
                results.allPassed = false;
                results.failedCases.push(`Error in test case: ${testCase.input}`);
            } else {
                const output = response.run.stdout.trim();
                const expectedOutput = testCase.expectedOutput.toString();
                
                if (output !== expectedOutput) {
                    results.allPassed = false;
                    results.failedCases.push(`Failed for input ${testCase.input}`);
                }
            }
        }

        return results;
    }

    async compilePiston(code, language, input = []) {
        const languageMap = {
            'python': 'python',
            'javascript': 'javascript',
            'cpp': 'cpp',
            'java': 'java'
        };

        const payload = {
            language: languageMap[language],
            version: "latest",
            files: [{ name: "main", content: code }],
            stdin: input.join('\n'),
            compile_timeout: 10000,
            run_timeout: 3000,
            compile_memory_limit: -1,
            run_memory_limit: -1
        };

        const response = await fetch('https://emkc.org/api/v2/piston/execute', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        return response.json();
    }

    loadNextProblem() {
        this.loadRandomProblem();
        document.getElementById('next-problem').style.display = 'none';
        document.getElementById('error-display').style.display = 'none';
    }

    init() {
        this.initializeEventListeners();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const platform = new CodingChallengePlatform();
    platform.init();
});