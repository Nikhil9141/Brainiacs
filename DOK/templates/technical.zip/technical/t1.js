// const questions = [
//     "Write a program to print 'Hello, World!'",
//     "Write a program to calculate the factorial of a number.",
//     "Write a program to reverse a string.",
// ];

// let currentQuestion = 0;

// const clientId = "ade6320456000026af98662799d78cd9"; // Replace with your JDoodle client ID
// const clientSecret = "b87bf72f90cec9e281b0f87bbd5b96e9c23d0a484503ceb0a1e317fdd01a40cc"; // Replace with your JDoodle client secret

// document.getElementById("run-code-btn").addEventListener("click", async () => {
//     const code = document.getElementById("code-input").value;
//     const language = document.getElementById("language").value;

//     if (!code) {
//         alert("Please write some code!");
//         return;
//     }

//     // Map language options to Judge0 IDs
//     const languageMap = {
//         c: 50,
//         cpp: 54,
//         java: 62,
//         python: 71,
//         javascript: 63,
//     };

//     try {
//         // Sending code for execution
//         const response = await fetch("https://api.jdoodle.com/v1/execute", {
//             method: "POST",
//             headers: {
//                 "Content-Type": "application/json",
//                 "Client-ID": clientId,
//                 "Client-Secret": clientSecret
//             },
//             body: JSON.stringify({
//                 source_code: code,
//                 language_id: languageMap[language],
//             }),
//         });

//         const result = await response.json();

//         // Check if there was an error from JDoodle
//         if (result.error) {
//             throw new Error(result.error);
//         }

//         const token = result.token;

//         // Polling for result
//         let output = "Processing...";
//         while (output === "Processing...") {
//             const status = await fetch(
//                 `https://api.jdoodle.com/v1/submissions/${token}`,
//                 {
//                     method: "GET",
//                     headers: {
//                         "Client-ID": clientId,
//                         "Client-Secret": clientSecret
//                     },
//                 }
//             );

//             const statusResult = await status.json();
//             if (statusResult.stdout) {
//                 output = statusResult.stdout;
//             } else if (statusResult.stderr) {
//                 output = statusResult.stderr;
//             } else {
//                 output = "Processing...";
//             }
//         }

//         // Display output or error
//         document.getElementById("output-result").textContent = output;

//         // Show "Next" button if code executed correctly
//         if (output.trim() === "Hello, World!\n") {
//             document.getElementById("next-btn").style.display = "inline-block";
//         } else {
//             document.getElementById("next-btn").style.display = "none";
//         }

//     } catch (error) {
//         document.getElementById("output-result").textContent = `Error: ${error.message}. Please try again!`;
//         console.error("Error:", error);
//     }
// });

// document.getElementById("next-btn").addEventListener("click", () => {
//     currentQuestion++;
//     if (currentQuestion < questions.length) {
//         document.getElementById("question-text").textContent =` Question ${currentQuestion + 1}: ${questions[currentQuestion]}`;
//         document.getElementById("code-input").value = "";
//         document.getElementById("output-result").textContent = "";
//         document.getElementById("next-btn").style.display = "none";
//     } else {
//         alert("Congratulations! You have completed all questions.");
//     }
// });

const questions = [
    "Write a program to print 'Hello, World!'",
    "Write a program to calculate the factorial of a number.",
    "Write a program to reverse a string.",
];

let currentQuestion = 0;

// Event listener for the "Run Code" button
document.getElementById("submit-btn").addEventListener("click", async () => {
    const code = document.getElementById("code-input").value;
    const language = document.getElementById("language").value;

    if (!code) {
        alert("Please write some code!");
        return;
    }

    // Prepare the payload for Piston API
    const payload = {
        language: language,
        version: "/api/v2/", // Use the latest version of the language
        files: [
            {
                name: "main",
                content: code,
            },
        ],
    };

    // Call Piston API
    try {
        const response = await fetch("https://emkc.org/api/v2/piston/execute", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        });

        const result = await response.json();

        // Display Output
        if (result.run && result.run.stdout) {
            document.getElementById("output-result").textContent =
                result.run.stdout;
        } else if (result.run && result.run.stderr) {
            document.getElementById("output-result").textContent =
                "Error:\n" + result.run.stderr;
        } else {
            document.getElementById("output-result").textContent =
                "Unexpected error occurred!";
        }
    } catch (error) {
        document.getElementById("output-result").textContent =
            "Error executing the code. Please try again!";
    }
});

// Event listener for the "Next Question" button
document.getElementById("next-btn").addEventListener("click", () => {
    currentQuestion++;
    if (currentQuestion < questions.length) {
        document.getElementById("question-text").textContent =
            `Question ${currentQuestion + 1}: ${questions[currentQuestion]}`;
        document.getElementById("code-input").value = "";
        document.getElementById("output-result").textContent = "";
    } else {
        alert("Congratulations! You have completed all questions.");
    }
});